
actions :create
default_action :create

attribute :x, kind_of: [ String ], name_attribute: true
